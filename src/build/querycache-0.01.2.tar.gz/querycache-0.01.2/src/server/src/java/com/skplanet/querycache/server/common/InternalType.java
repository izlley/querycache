package com.skplanet.querycache.server.common;

import com.skplanet.querycache.thrift.TTypeId;

public class InternalType {
  static public enum CORE_RESULT {
    CORE_SUCCESS,
    CORE_SUCCESS_WITH_INFO,
    CORE_FAILURE,
  }
}
