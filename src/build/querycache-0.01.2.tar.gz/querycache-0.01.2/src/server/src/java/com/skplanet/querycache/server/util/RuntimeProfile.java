package com.skplanet.querycache.server.util;

public class RuntimeProfile {
}
