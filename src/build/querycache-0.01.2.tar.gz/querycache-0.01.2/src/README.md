Apache Querycache (TM) @VERSION@
======================

The Querycache (TM) is a smart distributed cache for storing 
SQL results from heterogeneous storage systems.

![Overview](https://raw.github.com/izlley/querycache/master/docs/images/querycache_overview.jpg)
